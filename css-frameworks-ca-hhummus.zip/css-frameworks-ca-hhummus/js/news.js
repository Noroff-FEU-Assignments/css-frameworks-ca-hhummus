// container for cards
let cardBody = document.querySelector('.container-of-all-cards');

// cards array
const newsArray = [
	{
		newsImage: '/img/news/news-1.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-3.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-3.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-4.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-5.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-6.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-7.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
    {
		newsImage: '/img/news/news-8.jpeg',
		newsT: 'Nunc porttitor vel.',
		newsP: 'Nunc malesuada eget est fringilla dapibus.',
		newsMoreButton: 'More'
    },
];


// forEach through array of cards and display in html 
newsArray.forEach(function(cardElements) {
	cardBody.innerHTML += `
							<div class='card__container col-sm-4'>
							<div class='card'>
								<img src=${cardElements.newsImage} class= 'card-img-top card-image alt=''>
								
								<div class='card-body card-body-news'>
									<h5 class='card-title'>${cardElements.newsT}</h5>
									<p class='card-text'>${cardElements.newsP}</p>
									<a href='#' class='btn btn-primary card-button'>${cardElements.newsMoreButton}</a>
								</div>
							</div>
							</div>
                    		`;
});
